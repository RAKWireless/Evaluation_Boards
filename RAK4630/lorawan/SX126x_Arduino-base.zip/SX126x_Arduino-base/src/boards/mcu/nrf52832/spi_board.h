#ifndef SPI_BOARD_H
#define SPI_BOARD_H
#include <SPI.h>
extern SPIClass SPI_LORA;

void initSPI(void);
#endif // SPI_BOARD_H