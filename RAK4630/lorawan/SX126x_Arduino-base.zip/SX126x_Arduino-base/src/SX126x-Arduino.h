#ifndef _SX126X_ARDUINO_H
#define _SX126X_ARDUINO_H

#include "boards/mcu/board.h"
#include "radio/radio.h"

#endif // _SX126X_ARDUINO_H